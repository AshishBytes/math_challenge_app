import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class GameState with ChangeNotifier {
  int score = 0;
  int timeLeft = 30;
  String currentQuestion = "";
  List<int> options = [];
  int correctAnswer = 0;
  bool isGameOver = false;
  late Timer _timer;

  GameState() {
    _generateNewQuestion();
    _startTimer();
  }

  void _generateNewQuestion() {
    Random random = Random();
    int num1 = random.nextInt(10) + 1;
    int num2 = random.nextInt(10) + 1;
    String operation = random.nextBool() ? '+' : '-';
    int answer;

    if (operation == '+') {
      answer = num1 + num2;
      currentQuestion = '$num1 + $num2';
    } else {
      answer = num1 - num2;
      currentQuestion = '$num1 - $num2';
    }

    correctAnswer = answer;

    // Generate 3 random wrong options
    options = [answer];
    while (options.length < 4) {
      int wrongAnswer = random.nextInt(20) + 1;
      if (!options.contains(wrongAnswer)) {
        options.add(wrongAnswer);
      }
    }
    options.shuffle();
    notifyListeners();
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (timeLeft > 0) {
        timeLeft--;
      } else {
        isGameOver = true;
        _timer.cancel();
        notifyListeners();
      }
    });
  }

  void answerQuestion(int selectedAnswer) {
    if (selectedAnswer == correctAnswer) {
      score += 10;
      _generateNewQuestion();
    } else {
      isGameOver = true;
      _timer.cancel();
    }
    notifyListeners();
  }

  void resetGame() {
    score = 0;
    timeLeft = 30;
    isGameOver = false;
    _generateNewQuestion();
    _startTimer();
    notifyListeners();
  }

  void stopGame() {
    _timer.cancel();
    isGameOver = true;
    notifyListeners();
  }
}
