import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'game_state.dart';

class GamePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final gameState = Provider.of<GameState>(context);

    return Scaffold(
      appBar: AppBar(title: Text('Math Challenge')),
      body: gameState.isGameOver
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Game Over', style: TextStyle(fontSize: 32)),
                  Text('Score: ${gameState.score}', style: TextStyle(fontSize: 24)),
                  ElevatedButton(
                    onPressed: () {
                      gameState.resetGame();
                    },
                    child: Text('Play Again'),
                  ),
                ],
              ),
            )
          : Column(
              children: [
                LinearProgressIndicator(
                  value: gameState.timeLeft / 30,
                ),
                Text(gameState.currentQuestion, style: TextStyle(fontSize: 30)),
                SizedBox(height: 20),
                for (var option in gameState.options)
                  ElevatedButton(
                    onPressed: () => gameState.answerQuestion(option),
                    child: Text(option.toString(), style: TextStyle(fontSize: 24)),
                  ),
                Spacer(),
                Text('Score: ${gameState.score}', style: TextStyle(fontSize: 24)),
              ],
            ),
    );
  }
}
