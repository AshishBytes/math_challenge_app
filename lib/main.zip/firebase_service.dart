import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> submitScore(int score) async {
    await _firestore.collection('leaderboard').add({
      'score': score,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot> getLeaderboard() {
    return _firestore
        .collection('leaderboard')
        .orderBy('score', descending: true)
        .limit(10)
        .snapshots();
  }
}
